name = 'discrete'

import fit, simulate, combinatorics
