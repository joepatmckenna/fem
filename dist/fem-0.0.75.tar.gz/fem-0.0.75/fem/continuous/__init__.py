name = 'continuous'

import fit, simulate
