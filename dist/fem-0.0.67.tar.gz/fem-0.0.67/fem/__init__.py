name = 'fem'

import fortran_module
import discrete.simulate
import discrete.fit
import continuous.simulate
import continuous.fit
