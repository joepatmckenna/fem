Free Energy Minimization
========================

Quick Start
-----------
- Install ``fem``:

  .. code-block:: sh

     pip install fem


- Load ``fem`` in your Python script:

  .. code-block:: python

     import fem


Online documentation:
    http://joepatmckenna.github.io/fem

Source code repository:
    https://github.com/joepatmckenna/fem

Python package index:
    https://pypi.python.org/pypi/fem


